# Bakery startup dummy dataset: revised timeline

240 daily records for eight categories, exactly 30 consecutive dates per category: 10 October to 8 November 2026 inclusive. Prepared for a demonstration as of 9 November 2026 with the user's explicit permission to revise the timeline as dummy data.

Dates were assigned in each category's prior chronological order. Quantities, categories, original source dates/products, source totals and scaling factors were unchanged. previous_demo_sales_date preserves the previous shifted date. original_sales_date preserves the original French bakery date. The new timeline compresses source gaps and may change weekdays. No original weekday, holiday, season or weather relationship is asserted. No context factors were fabricated.

Source: user-provided Bakery sales.csv, associated with https://www.kaggle.com/datasets/matthieugimbert/french-bakery-daily-sales . Original source SHA-256: af5eede55b6eb2efb6bebb0e6dd1a51568c7eb73554d2f8ad2563081025681b2 . Reuse licence has not been independently verified here.

The eight source-to-bun substitutions are fictional pattern substitutions, not product equivalences:
- CROISSANT -> Butter Sugar Bun
- PAIN AUX RAISINS -> Coconut Bun
- FORMULE SANDWICH -> Chicken Sausage Bun
- PAIN AU CHOCOLAT -> Red Bean Bun
- BANETTE -> Cheese Bun
- ECLAIR -> Custard Bun
- BRIOCHE -> Mexican Coffee Bun
- SANDWICH COMPLET -> Chicken Floss Bun

Source quantities were summed by original date/product, including negative lines as returns/corrections (a demo assumption). Negative daily nets would be excluded; none occurred for selected donor products. Full donor histories were scaled to illustrative positive-day medians of 60, 40, 55, 45, 50, 40, 50 and 45 units respectively, in the mapping order above, then rounded halves up. The latest 30 observed records per category were retained before assigning the revised dummy timeline. Values were not tuned to make a particular model outperform another.

Import into daily_sales_records only after inspecting the current importer/schema. Map bread_category to existing category UUIDs. data_origin=IMPORTED_HISTORICAL indicates the external-file pathway; data_usage=ADAPTED_DEMO and timeline_type=DUMMY_CONSECUTIVE_DATES must remain recorded in import metadata/documentation. Existing IMPORTED_HISTORICAL_ONLY evaluation labels do not by themselves communicate the dummy adaptation. source_daily_result_id must be null. Do not use SIMULATION_GENERATED without satisfying its existing linked-result requirements. Extra provenance fields are not necessarily database columns.

is_validated=false stages records for review. After input validation and mapping review, the importer must deliberately set is_validated=true for accepted rows. Existing history selection otherwise rejects them. The source reference uses adapted-demo-timeline-v2 to distinguish this revision. If any earlier demo dataset was already imported, reconcile those rows explicitly before importing; distinct revision references alone do not prevent overlap on category/date. Do not import both versions as additional independent history or overwrite actual sales.

With only this dataset selected, each category has 24 earlier observations (10 October to 2 November), producing 23 fitting examples because the first observation supplies context, and 6 holdout observations (3 to 8 November). Additional existing history may alter the actual split.

Checks passed: 240 unique category/date records, eight exact categories, 30 consecutive dates per category, nonnegative integer quantities, no date after 8 November 2026, quantities unchanged from the previous 30-record version. No database import, training or activation performed. This demonstrates behaviour on adapted dummy data, not real-world prediction accuracy.
